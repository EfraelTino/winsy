<?php
if (!isset($_GET['puntos'])) {
    // Si no hay parámetro, vuelve a la página anterior
    echo "<script>window.history.back();</script>";
    exit;
}

$puntos = $_GET['puntos'];
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instrucciones del juego</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<style>
    /* poppins-latin-400-normal */
/* poppins-latin-400-normal */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-display: swap;
  font-weight: 400;
  src: url(https://cdn.jsdelivr.net/fontsource/fonts/poppins@latest/latin-400-normal.woff2) format('woff2'), url(https://cdn.jsdelivr.net/fontsource/fonts/poppins@latest/latin-400-normal.woff) format('woff');
  unicode-range: U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;
}

/* poppins-latin-700-normal */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-display: swap;
  font-weight: 700;
  src: url(https://cdn.jsdelivr.net/fontsource/fonts/poppins@latest/latin-700-normal.woff2) format('woff2'), url(https://cdn.jsdelivr.net/fontsource/fonts/poppins@latest/latin-700-normal.woff) format('woff');
  unicode-range: U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;
}

/* poppins-latin-800-normal */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-display: swap;
  font-weight: 800;
  src: url(https://cdn.jsdelivr.net/fontsource/fonts/poppins@latest/latin-800-normal.woff2) format('woff2'), url(https://cdn.jsdelivr.net/fontsource/fonts/poppins@latest/latin-800-normal.woff) format('woff');
  unicode-range: U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;
}
    *{
  overflow: hidden;
  font-family: 'Poppins';
    }
    .bg-principal {
       /* background: #d34d68; */
        background-image: url('./assets/fondo__.jpeg')
    }

    .bg-buttons {
        background: linear-gradient(90deg, rgba(156, 97, 214, 1) 0%, rgba(229, 76, 53, 1) 100%);
    }

    .text-shadow-title {
        text-shadow: 0px 1px 8px #ff7bf8;
    }
</style>

<body class="bg-principal min-h-screen bg-cover bg-no-repeat bg-center flex flex-col justify-evenly items-center p-0 m-0 p-12">
    <h1 class="text-[#f8e8ff] font-bold text-3xl text-center">
        ¡Terminaste tu <br> Ruta Finandina!
    </h1>
    <div class="flex items-center w-full">
        <img src="./assets/BATER.png" alt="" class="w-1/2 mx-auto">
        <p class="font-bold text-3xl text-center w-1/2 text-[#f8e8ff]">
            <?php echo $puntos ? $puntos : 0 ?>
        </p>
    </div>
    <h2 class="text-[#f8e8ff] font-bold text-3xl text-center">
        Acércate a un asesor Finandina para reclamar tu obsequio.
    </h2>
    <img src="./assets/logo.png" alt="" class="w-[70%]">
</body>
</html>
