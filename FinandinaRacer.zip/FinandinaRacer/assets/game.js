// game.js - Juego de Carreras Neón

// Configuración del juego
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const startScreen = document.getElementById('start-screen');
const gameOverScreen = document.getElementById('game-over');
const startButton = document.getElementById('start-button');
const restartButton = document.getElementById('restart-button');
const scoreElement = document.getElementById('score');
const fuelElement = document.getElementById('fuel');
const fuelLevelElement = document.getElementById('fuel-level');
const levelElement = document.getElementById('level');
const finalScoreElement = document.getElementById('final-score');
const touchControls = document.getElementById('touch-controls');
const leftBtn = document.getElementById('left-btn');
const rightBtn = document.getElementById('right-btn');

// Variables del juego
let gameRunning = false;
let score = 0;
let fuel = 100;
let level = 1;
let roadSpeed = 5;
let lastTime = 0;
let enemyTimer = 0;
let obstacleTimer = 0;
let turboTimer = 0;
let turboActive = false;
let turboEndTime = 0;

// Dimensiones de la carretera
const road = {
    width: canvas.width * 0.8,
    x: canvas.width * 0.1,
    laneWidth: 0,
    lanes: 3
};
road.laneWidth = road.width / road.lanes;

// Jugador
const player = {
    x: road.x + road.laneWidth * 1.5 - 25,
    y: canvas.height - 100,
    width: 50,
    height: 80,
    lane: 1, // 0: izquierda, 1: centro, 2: derecha
    speed: 0,
    moving: false,
    targetX: 0
};

// Líneas de la carretera
const roadLines = [];
const lineHeight = 20;
const lineWidth = 10;
const lineGap = 40;

// Inicializar líneas de carretera
for (let i = 0; i < canvas.height / (lineHeight + lineGap); i++) {
    roadLines.push({
        x: canvas.width / 2 - lineWidth / 2,
        y: i * (lineHeight + lineGap),
        width: lineWidth,
        height: lineHeight,
        color: '#0ff'
    });
}

// Enemigos
let enemies = [];

// Obstáculos
let obstacles = [];
const obstacleTypes = ['puddle', 'cone', 'barrier', 'turbo'];

// Crear imágenes (en un entorno real, estas serían cargadas desde archivos)
function createImage(color, width, height, type = 'car') {
    const img = document.createElement('canvas');
    img.width = width;
    img.height = height;
    const ctx = img.getContext('2d');
    
    switch(type) {
        case 'car':
            // Cuerpo del coche
            ctx.fillStyle = color;
            ctx.fillRect(0, 0, width, height);
            
            // Ventanas
            ctx.fillStyle = '#a8d0e6';
            ctx.fillRect(5, 5, width - 10, 15);
            ctx.fillRect(5, 25, width - 10, 15);
            
            // Luces neón
            ctx.strokeStyle = color;
            ctx.lineWidth = 2;
            ctx.shadowBlur = 10;
            ctx.shadowColor = color;
            ctx.strokeRect(2, 2, width - 4, height - 4);
            
            // Ruedas
            ctx.fillStyle = '#333';
            ctx.fillRect(-3, 10, 3, 15);
            ctx.fillRect(width, 10, 3, 15);
            ctx.fillRect(-3, 45, 3, 15);
            ctx.fillRect(width, 45, 3, 15);
            break;
            
        case 'puddle':
            ctx.fillStyle = '#00f';
            ctx.beginPath();
            ctx.ellipse(width/2, height/2, width/2, height/2, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#0ff';
            ctx.lineWidth = 2;
            ctx.shadowBlur = 10;
            ctx.shadowColor = '#0ff';
            ctx.stroke();
            break;
            
        case 'cone':
            ctx.fillStyle = '#ff0';
            ctx.beginPath();
            ctx.moveTo(width/2, 0);
            ctx.lineTo(width, height);
            ctx.lineTo(0, height);
            ctx.closePath();
            ctx.fill();
            ctx.strokeStyle = '#ff0';
            ctx.lineWidth = 2;
            ctx.shadowBlur = 10;
            ctx.shadowColor = '#ff0';
            ctx.stroke();
            break;
            
        case 'barrier':
            ctx.fillStyle = '#f00';
            ctx.fillRect(0, 0, width, height);
            ctx.strokeStyle = '#f00';
            ctx.lineWidth = 2;
            ctx.shadowBlur = 10;
            ctx.shadowColor = '#f00';
            ctx.strokeRect(2, 2, width-4, height-4);
            
            // Patrón de advertencia
            ctx.fillStyle = '#000';
            for (let i = 0; i < 3; i++) {
                ctx.fillRect(0, i * (height/3), width, 5);
            }
            break;
            
        case 'turbo':
            ctx.fillStyle = '#0f0';
            ctx.beginPath();
            ctx.arc(width/2, height/2, width/2, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#0f0';
            ctx.lineWidth = 2;
            ctx.shadowBlur = 15;
            ctx.shadowColor = '#0f0';
            ctx.stroke();
            
            // Símbolo de turbo
            ctx.fillStyle = '#000';
            ctx.font = 'bold 20px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('T', width/2, height/2);
            break;
    }
    
    return img;
}

// Crear imágenes para el juego
const playerImg = createImage('#f0f', player.width, player.height);
const enemyImg = createImage('#0ff', 50, 80);
const puddleImg = createImage('#00f', 40, 40, 'puddle');
const coneImg = createImage('#ff0', 30, 50, 'cone');
const barrierImg = createImage('#f00', 50, 30, 'barrier');
const turboImg = createImage('#0f0', 40, 40, 'turbo');

// Dibujar la carretera con efecto neón
function drawRoad() {
    // Fondo oscuro
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Carretera
    ctx.fillStyle = '#111';
    ctx.fillRect(road.x, 0, road.width, canvas.height);
    
    // Bordes de la carretera con efecto neón
    ctx.strokeStyle = '#0ff';
    ctx.lineWidth = 5;
    ctx.shadowBlur = 15;
    ctx.shadowColor = '#0ff';
    ctx.beginPath();
    ctx.moveTo(road.x, 0);
    ctx.lineTo(road.x, canvas.height);
    ctx.moveTo(road.x + road.width, 0);
    ctx.lineTo(road.x + road.width, canvas.height);
    ctx.stroke();
    ctx.shadowBlur = 0;
    
    // Líneas de carril con efecto neón
    ctx.strokeStyle = '#0ff';
    ctx.lineWidth = 3;
    ctx.setLineDash([10, 20]);
    ctx.shadowBlur = 10;
    ctx.shadowColor = '#0ff';
    
    for (let i = 1; i < road.lanes; i++) {
        const x = road.x + i * road.laneWidth;
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
    }
    ctx.setLineDash([]);
    ctx.shadowBlur = 0;
    
    // Líneas centrales animadas
    ctx.fillStyle = '#0ff';
    ctx.shadowBlur = 10;
    ctx.shadowColor = '#0ff';
    roadLines.forEach(line => {
        ctx.fillRect(line.x, line.y, line.width, line.height);
    });
    ctx.shadowBlur = 0;
}

// Dibujar HUD
function drawHUD() {
    scoreElement.textContent = `PUNTUACIÓN: ${score}`;
    fuelElement.textContent = `COMBUSTIBLE: ${Math.max(0, Math.floor(fuel))}%`;
    fuelLevelElement.style.width = `${Math.max(0, fuel)}%`;
    levelElement.textContent = `NIVEL: ${level}`;
    
    // Cambiar color de la barra de combustible según el nivel
    if (fuel > 50) {
        fuelLevelElement.style.background = 'linear-gradient(to right, #0f0, #0f0)';
    } else if (fuel > 20) {
        fuelLevelElement.style.background = 'linear-gradient(to right, #ff0, #ff0)';
    } else {
        fuelLevelElement.style.background = 'linear-gradient(to right, #f00, #f00)';
    }
}

// Crear enemigo
function createEnemy() {
    const lane = Math.floor(Math.random() * road.lanes);
    enemies.push({
        x: road.x + lane * road.laneWidth + road.laneWidth/2 - 25,
        y: -80,
        width: 50,
        height: 80,
        lane: lane,
        speed: 3 + Math.random() * 2 + level * 0.5,
        zigzag: Math.random() * 2 - 1, // -1 a 1 para movimiento lateral
        zigzagSpeed: 0.5 + Math.random() * 1
    });
}

// Crear obstáculo
function createObstacle() {
    const type = obstacleTypes[Math.floor(Math.random() * obstacleTypes.length)];
    const lane = Math.floor(Math.random() * road.lanes);
    
    let width, height;
    switch(type) {
        case 'puddle': width = 40; height = 40; break;
        case 'cone': width = 30; height = 50; break;
        case 'barrier': width = 50; height = 30; break;
        case 'turbo': width = 40; height = 40; break;
    }
    
    obstacles.push({
        x: road.x + lane * road.laneWidth + road.laneWidth/2 - width/2,
        y: -height,
        width: width,
        height: height,
        lane: lane,
        type: type,
        speed: 3 + level * 0.3
    });
}

// Dibujar enemigos
function drawEnemies() {
    enemies.forEach(enemy => {
        ctx.drawImage(enemyImg, enemy.x, enemy.y, enemy.width, enemy.height);
    });
}

// Dibujar obstáculos
function drawObstacles() {
    obstacles.forEach(obstacle => {
        let img;
        switch(obstacle.type) {
            case 'puddle': img = puddleImg; break;
            case 'cone': img = coneImg; break;
            case 'barrier': img = barrierImg; break;
            case 'turbo': img = turboImg; break;
        }
        ctx.drawImage(img, obstacle.x, obstacle.y, obstacle.width, obstacle.height);
    });
}

// Dibujar jugador
function drawPlayer() {
    ctx.drawImage(playerImg, player.x, player.y, player.width, player.height);
    
    // Efecto de turbo activo
    if (turboActive) {
        ctx.strokeStyle = '#0f0';
        ctx.lineWidth = 3;
        ctx.shadowBlur = 20;
        ctx.shadowColor = '#0f0';
        ctx.strokeRect(player.x - 5, player.y - 5, player.width + 10, player.height + 10);
        ctx.shadowBlur = 0;
    }
}

// Actualizar posiciones
function updatePositions(deltaTime) {
    // Mover líneas de carretera
    roadLines.forEach(line => {
        line.y += roadSpeed;
        if (line.y > canvas.height) {
            line.y = -lineHeight;
        }
    });
    
    // Mover enemigos
    enemies.forEach((enemy, index) => {
        enemy.y += enemy.speed;
        
        // Movimiento en zigzag
        enemy.x += enemy.zigzag * enemy.zigzagSpeed;
        
        // Limitar movimiento dentro del carril
        const laneCenter = road.x + enemy.lane * road.laneWidth + road.laneWidth/2 - 25;
        if (enemy.x < laneCenter - 30) enemy.zigzag = Math.abs(enemy.zigzag);
        if (enemy.x > laneCenter + 30) enemy.zigzag = -Math.abs(enemy.zigzag);
        
        // Eliminar enemigos que salgan de la pantalla
        if (enemy.y > canvas.height) {
            enemies.splice(index, 1);
            score += 10; // Puntos por esquivar
        }
    });
    
    // Mover obstáculos
    obstacles.forEach((obstacle, index) => {
        obstacle.y += obstacle.speed;
        
        // Eliminar obstáculos que salgan de la pantalla
        if (obstacle.y > canvas.height) {
            obstacles.splice(index, 1);
        }
    });
    
    // Mover jugador suavemente entre carriles
    if (player.moving) {
        const dx = player.targetX - player.x;
        player.x += dx * 0.1;
        if (Math.abs(dx) < 1) {
            player.x = player.targetX;
            player.moving = false;
        }
    }
    
    // Actualizar nivel
    level = Math.floor(score / 1000) + 1;
}

// Detectar colisiones
function checkCollisions() {
    // Colisión con enemigos
    enemies.forEach((enemy, index) => {
        if (
            player.x < enemy.x + enemy.width &&
            player.x + player.width > enemy.x &&
            player.y < enemy.y + enemy.height &&
            player.y + player.height > enemy.y
        ) {
            // Colisión detectada
            enemies.splice(index, 1);
            fuel -= 20;
            
            // Efecto visual de colisión
            ctx.fillStyle = 'rgba(255, 0, 0, 0.5)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            if (fuel <= 0) {
                gameOver();
            }
        }
    });
    
    // Colisión con obstáculos
    obstacles.forEach((obstacle, index) => {
        if (
            player.x < obstacle.x + obstacle.width &&
            player.x + player.width > obstacle.x &&
            player.y < obstacle.y + obstacle.height &&
            player.y + player.height > obstacle.y
        ) {
            // Efecto según el tipo de obstáculo
            switch(obstacle.type) {
                case 'puddle':
                    // Derrape - reduce velocidad temporalmente
                    roadSpeed = Math.max(2, roadSpeed - 2);
                    score -= 5;
                    setTimeout(() => {
                        roadSpeed = 5 + level * 0.5;
                    }, 2000);
                    break;
                case 'cone':
                    score -= 10;
                    break;
                case 'barrier':
                    fuel -= 15;
                    break;
                case 'turbo':
                    score += 20;
                    turboActive = true;
                    turboEndTime = Date.now() + 3000; // 3 segundos de turbo
                    roadSpeed += 2;
                    break;
            }
            
            obstacles.splice(index, 1);
            
            if (fuel <= 0) {
                gameOver();
            }
        }
    });
    
    // Verificar fin del turbo
    if (turboActive && Date.now() > turboEndTime) {
        turboActive = false;
        roadSpeed = Math.max(5, roadSpeed - 2);
    }
}

// Game over
function gameOver() {
    gameRunning = false;
    finalScoreElement.textContent = `Puntuación final: ${score}`;
    gameOverScreen.style.display = 'flex';
}

// Bucle principal del juego
function gameLoop(timestamp) {
    if (!gameRunning) return;
    
    const deltaTime = timestamp - lastTime;
    lastTime = timestamp;
    
    // Actualizar temporizadores
    enemyTimer += deltaTime;
    obstacleTimer += deltaTime;
    
    // Generar enemigos cada 1-2 segundos
    if (enemyTimer > 1000 + Math.random() * 1000) {
        createEnemy();
        enemyTimer = 0;
    }
    
    // Generar obstáculos cada 1-3 segundos
    if (obstacleTimer > 1000 + Math.random() * 2000) {
        createObstacle();
        obstacleTimer = 0;
    }
    
    // Consumir combustible
    fuel -= 0.05;
    if (fuel <= 0) {
        gameOver();
    }
    
    // Limpiar canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Dibujar elementos
    drawRoad();
    drawEnemies();
    drawObstacles();
    drawPlayer();
    
    // Actualizar posiciones
    updatePositions(deltaTime);
    
    // Verificar colisiones
    checkCollisions();
    
    // Actualizar HUD
    drawHUD();
    
    // Solicitar siguiente frame
    requestAnimationFrame(gameLoop);
}

// Control del jugador
function movePlayer(direction) {
    if (!gameRunning) return;
    
    if (direction === 'left' && player.lane > 0) {
        player.lane--;
        player.targetX = road.x + player.lane * road.laneWidth + road.laneWidth/2 - player.width/2;
        player.moving = true;
    } else if (direction === 'right' && player.lane < road.lanes - 1) {
        player.lane++;
        player.targetX = road.x + player.lane * road.laneWidth + road.laneWidth/2 - player.width/2;
        player.moving = true;
    }
}

// Control por teclado
document.addEventListener('keydown', (e) => {
    switch(e.key) {
        case 'ArrowLeft':
        case 'a':
        case 'A':
            movePlayer('left');
            break;
        case 'ArrowRight':
        case 'd':
        case 'D':
            movePlayer('right');
            break;
    }
});

// Control táctil
leftBtn.addEventListener('touchstart', (e) => {
    e.preventDefault();
    movePlayer('left');
});

rightBtn.addEventListener('touchstart', (e) => {
    e.preventDefault();
    movePlayer('right');
});

// Detectar si es un dispositivo táctil y mostrar controles
if ('ontouchstart' in window || navigator.maxTouchPoints) {
    touchControls.style.display = 'flex';
}

// Iniciar juego
startButton.addEventListener('click', () => {
    startScreen.style.display = 'none';
    gameRunning = true;
    score = 0;
    fuel = 100;
    level = 1;
    roadSpeed = 5;
    enemies = [];
    obstacles = [];
    player.lane = 1;
    player.x = road.x + road.laneWidth * 1.5 - player.width/2;
    player.moving = false;
    turboActive = false;
    lastTime = performance.now();
    enemyTimer = 0;
    obstacleTimer = 0;
    gameLoop(performance.now());
});

// Reiniciar juego
restartButton.addEventListener('click', () => {
    gameOverScreen.style.display = 'none';
    gameRunning = true;
    score = 0;
    fuel = 100;
    level = 1;
    roadSpeed = 5;
    enemies = [];
    obstacles = [];
    player.lane = 1;
    player.x = road.x + road.laneWidth * 1.5 - player.width/2;
    player.moving = false;
    turboActive = false;
    lastTime = performance.now();
    enemyTimer = 0;
    obstacleTimer = 0;
    gameLoop(performance.now());
});