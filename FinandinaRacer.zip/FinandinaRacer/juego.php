<?php
include "../logica/conexion.php";

$documento = $_GET['documento'];

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Ruta Neon Arcade <?php echo $documento; ?></title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <p hidden id="documento"><?php echo $documento; ?></p>
  <canvas id="gameCanvas"></canvas>
  <script src="config.js"></script>
  <script src="game.js"></script>
</body>
</html>
