// Configuración general, assets y helpers
let documento = document.getElementById('documento').textContent;
localStorage.setItem("doc", documento);
//localStorage.setItem('neon_race_highscore', 0);
//console.log(documento);
const ASSETS = {
  player: 'assets/player.png',
  enemy: 'assets/enemy.png',
  crash: 'assets/crash.png',
  puddle: 'assets/puddle.png',
  cone: 'assets/cone.png',
  barrier: 'assets/barrier.png',
  turbo: 'assets/turbo.png',
  battery: [
    'assets/battery0.png',
    'assets/battery1.png',
    'assets/battery2.png',
    'assets/battery3.png',
    'assets/battery4.png'
  ],
  celebration: 'assets/celebration.png',
  crashSound: 'assets/crash.mp3',
  pointSound: 'assets/point.mp3',
  music: 'assets/music.mp3'
};


const GAME = {
  lanes: 3,
  duration: 120,
  batteryStates: 4,
  mobileSpeed: 0, // Se sobrescribe según dispositivo
  desktopSpeed: 0 // Se sobrescribe según dispositivo
};

// Detectar plataforma
function isAndroid() {
  return /Android/i.test(navigator.userAgent);
}

function isIOS() {
  return /iPhone|iPad|iPod/i.test(navigator.userAgent);
}

function isDesktop() {
  return !isAndroid() && !isIOS();
}

// CONFIGURACIÓN ESPECÍFICA POR DISPOSITIVO
const DEVICE_CONFIG = {
  android: {
    // Velocidades base
    baseSpeed: 3,
    speedMultiplier: 50,
    moveSpeed: 2.8,
    
    // Velocidades de enemigos
    enemyBaseSpeed: 2,
    enemySpawnInterval: 1.8,
    enemyHorizontalSpeed: 1,
    enemyTurboMultiplier: 1.3,
    
    // Velocidades de obstáculos
    obstacleDescentMultiplier: 140,
    obstacleSpawnInterval: 1,
    
    // Turbo
    turboSpeedMultiplier: 3,
    turboDuration: 3,
    turboAcceleration: 2.3,
    enemyTurboDuration: 1.8,
    
    // Tiempos del juego
    startDelay: 3,
    finishTime: 120,
    gameDuration: 122,
    
    // Distancias y puntos
    closeDistance: 80,
    closePoints: 10,
    crashPointsPenalty: 1,
    obstaclePointsPenalty: 2,
    turboPointsReward: 20,
    closePassReward: 10,
    
    // Física
    crashSpeedMultiplier: 0.5,
    crashDuration: 1,
    puddleCrashMultiplier: 0.6,
    puddleCrashDuration: 2,
    shakeRecoveryTime: 2,
    
    // Spawn
    maxEnemies: 5,
    maxObstacles: 8,
    enemySpawnY: -120,
    obstacleSpawnY: -100,
    
    // Divisores
    dividerInterval: 80,
    dividerSegmentHeight: 30,
    
    // Tolerancia de colisiones
    playerCollisionRadiusX: 40,
    playerCollisionRadiusY: 60,
    obstacleCollisionRadiusX: 35,
    obstacleCollisionRadiusY: 55,
    finishLineThreshold: 70,
    
    // Movimiento horizontal
    horizontalMoveSpeedReduction: 1
  },
  
  ios: {
    // Velocidades base
    baseSpeed: 5,
    speedMultiplier: 80,
    moveSpeed: 3.5,
    
    // Velocidades de enemigos
    enemyBaseSpeed: 4,
    enemySpawnInterval: 1.2,
    enemyHorizontalSpeed: 1.8,
    enemyTurboMultiplier: 1.4,
    
    // Velocidades de obstáculos
    obstacleDescentMultiplier: 150,
    obstacleSpawnInterval: 1,
    
    // Turbo
    turboSpeedMultiplier: 2,
    turboDuration: 3,
    turboAcceleration: 2.5,
    enemyTurboDuration: 2,
    
    // Tiempos del juego
    startDelay: 3,
    finishTime: 120,
    gameDuration: 122,
    
    // Distancias y puntos
    closeDistance: 80,
    closePoints: 10,
    crashPointsPenalty: 1,
    obstaclePointsPenalty: 2,
    turboPointsReward: 20,
    closePassReward: 10,
    
    // Física
    crashSpeedMultiplier: 0.5,
    crashDuration: 1,
    puddleCrashMultiplier: 0.6,
    puddleCrashDuration: 2,
    shakeRecoveryTime: 2,
    
    // Spawn
    maxEnemies: 5,
    maxObstacles: 8,
    enemySpawnY: -120,
    obstacleSpawnY: -100,
    
    // Divisores
    dividerInterval: 80,
    dividerSegmentHeight: 30,
    
    // Tolerancia de colisiones
    playerCollisionRadiusX: 40,
    playerCollisionRadiusY: 60,
    obstacleCollisionRadiusX: 35,
    obstacleCollisionRadiusY: 55,
    finishLineThreshold: 70,
    
    // Movimiento horizontal
    horizontalMoveSpeedReduction: 1
  },
  
  desktop: {
    
    // Velocidades base
    baseSpeed: 8,
    speedMultiplier: 120,
    moveSpeed: 5,
    
    // Velocidades de enemigos
    enemyBaseSpeed: 5,
    enemySpawnInterval: 1.5,
    enemyHorizontalSpeed: 2,
    enemyTurboMultiplier: 1.5,
    
    // Velocidades de obstáculos
    obstacleDescentMultiplier: 120,
    obstacleSpawnInterval: 2.5,
    
    // Turbo
    turboSpeedMultiplier: 2,
    turboDuration: 3,
    turboAcceleration: 2.5,
    enemyTurboDuration: 2,
    
    // Tiempos del juego
    startDelay: 3,
    finishTime: 120,
    gameDuration: 122,
    
    // Distancias y puntos
    closeDistance: 80,
    closePoints: 10,
    crashPointsPenalty: 1,
    obstaclePointsPenalty: 2,
    turboPointsReward: 20,
    closePassReward: 10,
    
    // Física
    crashSpeedMultiplier: 0.5,
    crashDuration: 1,
    puddleCrashMultiplier: 0.6,
    puddleCrashDuration: 2,
    shakeRecoveryTime: 2,
    
    // Spawn
    maxEnemies: 5,
    maxObstacles: 8,
    enemySpawnY: -120,
    obstacleSpawnY: -100,
    
    // Divisores
    dividerInterval: 80,
    dividerSegmentHeight: 30,
    
    // Tolerancia de colisiones
    playerCollisionRadiusX: 40,
    playerCollisionRadiusY: 60,
    obstacleCollisionRadiusX: 35,
    obstacleCollisionRadiusY: 55,
    finishLineThreshold: 70,
    
    // Movimiento horizontal
    horizontalMoveSpeedReduction: 1
  }
};

// Función para obtener la configuración según el dispositivo
function getDeviceConfig() {
  if(isAndroid()) {
    console.log("Android");
    return DEVICE_CONFIG.android;
  } else if(isIOS()) {
    console.log("IOS");
    return DEVICE_CONFIG.ios;
  } else {
    console.log("Soy desktop");
    return DEVICE_CONFIG.desktop;
  }
}

// Obtener configuración actual
const CONFIG = getDeviceConfig();

// Actualizar GAME con valores del dispositivo
GAME.mobileSpeed = CONFIG.baseSpeed;
GAME.desktopSpeed = CONFIG.baseSpeed;

// Exportar para uso en game.js
const GAME_CONFIG = CONFIG;
const CURRENT_DEVICE = isAndroid() ? 'android' : (isIOS() ? 'ios' : 'desktop');
