function isAndroid() {
  return /Android/i.test(navigator.userAgent);
}
function isIOS() {
  return /iPhone|iPad|iPod/i.test(navigator.userAgent);
}

let canvas, ctx, width, height;
let assets = {}, sounds = {};
let lanes = GAME.lanes;
let laneWidth, lanePositions = [];
let player, enemies = [], obstacles = [];
let score = 0, gameTime = GAME.duration;
let lastFrame = performance.now();
let running = true, showCelebration = false, celebrationImg;
let turboTrail = [], turboActive = false, turboTimer = 0, metaActive = false, crashTimer = 0, shakeTimer = 0;
let batteryLevel = 4;
let enemyTurboTimer = 0;
let isPortrait = true;

let movingLeft = false;
let movingRight = false;
let touchStartX = 0;
let touchStartY = 0;

let gameStartTime = 0;
let gameElapsedTime = 0;
let pausedTime = 0;

const ACTIVE_CONFIG = GAME_CONFIG;

const SCALE_ENEMY = 0.9;
const SCALE_OBSTACLE = 0.35;
const MIN_X_MARGIN = 18 + 40;
const MAX_X_MARGIN = () => width - 18 - 40;
const MOVE_SPEED = ACTIVE_CONFIG.moveSpeed;
const SPEED_MULTIPLIER = ACTIVE_CONFIG.speedMultiplier;
const ENEMY_SPAWN_INTERVAL = ACTIVE_CONFIG.enemySpawnInterval;
const OBSTACLE_SPAWN_INTERVAL = ACTIVE_CONFIG.obstacleSpawnInterval;
const OBSTACLE_DESCENT_MULTIPLIER = ACTIVE_CONFIG.obstacleDescentMultiplier;
const ENEMY_HORIZONTAL_SPEED = ACTIVE_CONFIG.enemyHorizontalSpeed;
const ROAD_LEFT_LIMIT = 18 + 20;
const ROAD_RIGHT_LIMIT = () => width - 18 - 20;
const START_DELAY = ACTIVE_CONFIG.startDelay;
const FINISH_TIME = ACTIVE_CONFIG.finishTime;
const TURBO_DURATION = ACTIVE_CONFIG.turboDuration;
const TURBO_SPEED_MULTIPLIER = ACTIVE_CONFIG.turboAcceleration;
const ENEMY_TURBO_DURATION = ACTIVE_CONFIG.enemyTurboDuration;
const ENEMY_TURBO_MULTIPLIER = ACTIVE_CONFIG.enemyTurboMultiplier;
const CLOSE_DISTANCE = ACTIVE_CONFIG.closeDistance;
const CLOSE_POINTS = ACTIVE_CONFIG.closePassReward;

let dividerOffset = 0;
let roadOffsetY = 0;
let enemySpawnTimer = 0, obstacleSpawnTimer = 0;
let startLineY = 0, finishLineY = -3000;
let countdownTimer = START_DELAY;
let gameReallyStarted = false;
let elapsedGameTime = 0;

function checkOrientation() {
  let currentOrientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
  
  if(currentOrientation === 'landscape' && (isAndroid() || isIOS())) {
    isPortrait = false;
    showOrientationWarning();
  } else {
    isPortrait = true;
    hideOrientationWarning();
  }
}

function showOrientationWarning() {
  let warning = document.getElementById('orientationWarning');
  if(!warning) {
    warning = document.createElement('div');
    warning.id = 'orientationWarning';
    warning.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.9);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
      font-family: Arial, sans-serif;
    `;
    warning.innerHTML = `
      <div style="
        background: #020310;
        border: 3px solid #ff00ff;
        padding: 40px;
        border-radius: 15px;
        text-align: center;
        color: #fff;
        box-shadow: 0 0 30px #ff00ff;
      ">
        <h2 style="color: #ff00ff; margin: 0 0 20px 0; font-size: 28px;">⚠️ ORIENTACIÓN</h2>
        <p style="font-size: 18px; margin: 0 0 20px 0;">
          Por favor, gira tu dispositivo a modo vertical para jugar
        </p>
        <p style="font-size: 14px; color: #ccc; margin: 0;">
          Este juego está optimizado solo para modo vertical
        </p>
      </div>
    `;
    document.body.appendChild(warning);
  }
  warning.style.display = 'flex';
}

function hideOrientationWarning() {
  let warning = document.getElementById('orientationWarning');
  if(warning) {
    warning.style.display = 'none';
  }
}

window.onload = async function () {
  checkOrientation();
  
  canvas = document.getElementById('gameCanvas');
  ctx = canvas.getContext('2d');
  resizeCanvas();
  await loadAssets();
  resetGame();

  document.addEventListener('touchstart', handleTouchStart, false);
  document.addEventListener('touchmove', handleTouchMove, false);
  document.addEventListener('touchend', handleTouchEnd, false);

  window.addEventListener('keydown', handleKeyDown);
  window.addEventListener('keyup', handleKeyUp);
  window.addEventListener('resize', resizeCanvas);
  window.addEventListener('orientationchange', () => {
    setTimeout(checkOrientation, 100);
  });
  window.addEventListener('contextmenu', e => e.preventDefault());
  
  requestAnimationFrame(gameLoop);
};

function resizeCanvas() {
  if(!ctx) return;
  let dpr = window.devicePixelRatio || 1;
  width = window.innerWidth;
  height = window.innerHeight;
  canvas.width = width * dpr;
  canvas.height = height * dpr;
  canvas.style.width = width + "px";
  canvas.style.height = height + "px";
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

  laneWidth = width / (lanes + 1);
  lanePositions = [];
  for(let i = 1; i <= lanes; i++) lanePositions.push(i * laneWidth - laneWidth / 2);
}

async function loadAssets() {
  for (let k in ASSETS) {
    if (Array.isArray(ASSETS[k])) {
      assets[k] = [];
      for (let url of ASSETS[k])
        assets[k].push(await loadImage(url));
    } else if (/\.(png|jpg|jpeg)$/i.test(ASSETS[k]))
      assets[k] = await loadImage(ASSETS[k]);
    else if (/\.(mp3|wav)$/i.test(ASSETS[k]))
      sounds[k] = new Audio(ASSETS[k]);
  }
}

function loadImage(src) {
  return new Promise(res=>{
    let img = new Image();
    img.src = src;
    img.onload = () => res(img);
  });
}

function resetGame() {
  score = 0;
  gameTime = GAME.duration;
  batteryLevel = 4;
  metaActive = false;
  showCelebration = false;
  turboActive = false;
  turboTimer = 0;
  enemyTurboTimer = 0;
  turboTrail = [];
  enemySpawnTimer = 0;
  obstacleSpawnTimer = 0;
  startLineY = height * 0.7;
  finishLineY = -3000;
  countdownTimer = START_DELAY;
  gameReallyStarted = false;
  elapsedGameTime = 0;
  dividerOffset = 0;
  roadOffsetY = 0;
  gameStartTime = 0;
  gameElapsedTime = 0;
  pausedTime = 0;
  
  player = {
    x: width / 2,
    y: height * 0.8,
    width: 64,
    height: 108,
    rotation: 0,
    speed: ACTIVE_CONFIG.baseSpeed,
    baseSpeed: ACTIVE_CONFIG.baseSpeed
  };
  enemies = [];
  obstacles = [];
  celebrationImg = null;
  running = true;
}

function handleKeyDown(e) {
  if(!running) return;
  if (e.key === 'ArrowLeft') movingLeft = true;
  if (e.key === 'ArrowRight') movingRight = true;
}

function handleKeyUp(e) {
  if (e.key === 'ArrowLeft') movingLeft = false;
  if (e.key === 'ArrowRight') movingRight = false;
}

function handleTouchStart(e) {
  if(!running) return;
  if(!canvas.contains(e.target)) return;
  
  e.preventDefault();
  
  if(e.touches.length > 0) {
    touchStartX = e.touches[0].clientX;
    touchStartY = e.touches[0].clientY;
    
    if(touchStartX < width / 2) {
      movingLeft = true;
      movingRight = false;
    } else {
      movingLeft = false;
      movingRight = true;
    }
  }
}

function handleTouchMove(e) {
  if(!running) return;
  if(!canvas.contains(e.target)) return;
  
  e.preventDefault();
  
  if(e.touches.length > 0) {
    let currentX = e.touches[0].clientX;
    
    if(currentX < width / 2) {
      movingLeft = true;
      movingRight = false;
    } else {
      movingLeft = false;
      movingRight = true;
    }
  }
}

function handleTouchEnd(e) {
  if(!running) return;
  
  e.preventDefault();
  movingLeft = false;
  movingRight = false;
  touchStartX = 0;
  touchStartY = 0;
}

function updatePlayerPosition(delta) {
  if (player.rotation) return;
  
  if(!gameReallyStarted) return;
  
  let moveSpeed = MOVE_SPEED * ACTIVE_CONFIG.horizontalMoveSpeedReduction;
  
  if(movingLeft) player.x -= moveSpeed;
  if(movingRight) player.x += moveSpeed;

  player.x = Math.min(MAX_X_MARGIN(), Math.max(MIN_X_MARGIN, player.x));
}

function gameLoop(now) {
  if (!running && !showCelebration) return;
  let delta = (now - lastFrame) / 1000;
  delta = Math.min(delta, 0.016);
  lastFrame = now;
  if (showCelebration) {
    drawCelebration();
    return;
  }
  updateGame(delta, now);
  render();
  requestAnimationFrame(gameLoop);
}

function updateGame(delta, now) {
  if(!gameReallyStarted) {
    if(gameStartTime === 0) gameStartTime = now;
    gameElapsedTime = (now - gameStartTime) / 1000;
    countdownTimer = START_DELAY - gameElapsedTime;
    
    if(countdownTimer <= 0) {
      gameReallyStarted = true;
      gameStartTime = now;
      gameElapsedTime = 0;
    }
    return;
  }

  if(running && gameReallyStarted) {
    gameElapsedTime = (now - gameStartTime) / 1000;
    elapsedGameTime = gameElapsedTime;
    gameTime = GAME.duration - elapsedGameTime;
    if(gameTime <= 0) gameTime = 0;

    updateBattery();

    let speedFactor = player.speed / player.baseSpeed;
    roadOffsetY -= (player.baseSpeed * speedFactor) * delta * SPEED_MULTIPLIER;
    if(roadOffsetY <= -120) roadOffsetY = 0;

    updatePlayerPosition(delta);

    enemySpawnTimer += delta;
    if(enemySpawnTimer >= ENEMY_SPAWN_INTERVAL) {
      spawnEnemy();
      enemySpawnTimer = 0;
    }

    obstacleSpawnTimer += delta;
    if(obstacleSpawnTimer >= OBSTACLE_SPAWN_INTERVAL) {
      spawnObstacle();
      obstacleSpawnTimer = 0;
    }

    updateEnemies(delta);
    updateObstacles(delta);

    let speedFactor2 = player.speed / player.baseSpeed;
    startLineY += (player.baseSpeed * speedFactor2) * delta * OBSTACLE_DESCENT_MULTIPLIER;

    if(elapsedGameTime >= FINISH_TIME) {
      finishLineY += (player.baseSpeed * speedFactor2) * delta * OBSTACLE_DESCENT_MULTIPLIER;
      checkFinishLine();
    } else {
      finishLineY = -3000;
    }

    if(turboActive) {
      turboTimer -= delta;
      if(turboTimer <= 0) {
        turboActive = false;
        player.speed = player.baseSpeed;
      }
    }

    if(enemyTurboTimer > 0) {
      enemyTurboTimer -= delta;
    }

    checkCollisions();

    if(crashTimer > 0) {
      crashTimer -= delta;
      if(crashTimer <= 0) {
        player.speed = player.baseSpeed;
        turboActive = false;
        turboTimer = 0;
      }
    }

    if(shakeTimer > 0) shakeTimer -= delta;
  }
}

function render() {
  drawBackground();
  drawRoad();
  drawDividers();
  drawStartLine();
  drawFinishLineDynamic();
  drawPlayer();
  drawEnemies();
  drawObstacles();
  drawTurboTrail();
  drawCountdown();
  drawBattery();
  drawScoreHUD();
  drawTurboStatus();
  drawControlButtons();
}
 
function drawControlButtons() {
  ctx.save();
  
  let radius = 35;
  let leftX = width / 2 - 120;
  let leftY = height - 130;
  let rightX = width / 2 + 120;
  let rightY = height - 130;
  
  // Círculo izquierdo
  ctx.fillStyle = 'rgba(0, 255, 247, 0.1)';
  ctx.strokeStyle = '#07fff7';
  ctx.lineWidth = 1.5;
  ctx.shadowBlur = 10;
  ctx.shadowColor = '#07fff7';
  
  ctx.beginPath();
  ctx.arc(leftX, leftY, radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  
  // Ícono flecha izquierda
  ctx.fillStyle = '#07fff7';
  ctx.font = 'bold 20px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.globalAlpha = 0.6;
  //ctx.fillText('◀', leftX, leftY);
  
  // Círculo derecho
  ctx.fillStyle = 'rgba(0, 255, 247, 0.1)';
  ctx.strokeStyle = '#07fff7';
  ctx.lineWidth = 1.5;
  ctx.shadowBlur = 10;
  ctx.shadowColor = '#07fff7';
  
  ctx.beginPath();
  ctx.arc(rightX, rightY, radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  
  // Ícono flecha derecha
  ctx.fillStyle = '#07fff7';
  ctx.font = 'bold 20px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.globalAlpha = 0.6;
  //ctx.fillText('▶', rightX, rightY);
  
  ctx.restore();
}



function drawBackground() {
  ctx.clearRect(0, 0, width, height);
  ctx.save();
  
  ctx.shadowBlur = 40;
  ctx.shadowColor = '#ff00ff';
  ctx.fillStyle = '#ff00ff';
  ctx.fillRect(0, 0, 18, height);
  
  ctx.shadowBlur = 60;
  ctx.shadowColor = '#ff1493';
  ctx.strokeStyle = '#ff1493';
  ctx.lineWidth = 3;
  ctx.strokeRect(0, 0, 18, height);
  
  ctx.shadowBlur = 40;
  ctx.shadowColor = '#ff00ff';
  ctx.fillStyle = '#ff00ff';
  ctx.fillRect(width - 18, 0, 18, height);
  
  ctx.shadowBlur = 60;
  ctx.shadowColor = '#ff1493';
  ctx.strokeStyle = '#ff1493';
  ctx.lineWidth = 3;
  ctx.strokeRect(width - 18, 0, 18, height);
  
  ctx.restore();
}

function drawRoad() {
  ctx.save();
  ctx.globalAlpha = 0.97;
  ctx.fillStyle = '#020310';
  ctx.fillRect(18, 0, width - 36, height);
  ctx.restore();
}

function drawDividers() {
  let inter = ACTIVE_CONFIG.dividerInterval;
  let segHeight = ACTIVE_CONFIG.dividerSegmentHeight;
  if(gameReallyStarted) {
    let speedFactor = player.speed / player.baseSpeed;
    dividerOffset -= (player.baseSpeed * speedFactor) * 2;
    if(dividerOffset <= -inter) dividerOffset = 0;
  }

  for (let lane = 1; lane < lanes; lane++) {
    let x = lanePositions[lane];
    for (let y = -segHeight - dividerOffset; y < height; y += inter) {
      ctx.save();
      ctx.beginPath();
      ctx.strokeStyle = '#07fff7';
      ctx.lineWidth = 5;
      ctx.shadowBlur = 14;
      ctx.shadowColor = '#07fff7';
      ctx.moveTo(x, y);
      ctx.lineTo(x, y + segHeight);
      ctx.stroke();
      ctx.restore();
      ctx.save();
      ctx.beginPath();
      ctx.strokeStyle = '#FFF';
      ctx.lineWidth = 1.5;
      ctx.moveTo(x, y + 6);
      ctx.lineTo(x, y + segHeight - 6);
      ctx.stroke();
      ctx.restore();
    }
  }
}

function drawStartLine() {
  let y = startLineY;
  if(y < -50 || y > height + 50) return;

  let tileSize = 16;
  let left = 18 + 5;
  let right = width - 18 - 5;

  for (let x = left; x < right; x += tileSize) {
    for (let row = 0; row < 3; row++) {
      ctx.save();
      ctx.fillStyle = (Math.floor(x/tileSize) + row) % 2 === 0 ? "#fff" : "#ff007f";
      ctx.shadowBlur = 8;
      ctx.shadowColor = "#ff007f";
      ctx.globalAlpha = 0.9;
      ctx.fillRect(x, y + row * tileSize, tileSize, tileSize);
      ctx.restore();
    }
  }

  ctx.save();
  ctx.font = 'bold 1.5rem Montserrat, Arial';
  ctx.fillStyle = '#fff';
  ctx.shadowBlur = 10;
  ctx.shadowColor = '#ff007f';
  ctx.textAlign = 'center';
  ctx.fillText('SALIDA', width / 2, y - 30);
  ctx.restore();
}

function drawFinishLineDynamic() {
  let y = finishLineY;
  if(y < -50 || y > height + 50) return;

  let tileSize = 16;
  let left = 18 + 5;
  let right = width - 18 - 5;

  for (let x = left; x < right; x += tileSize) {
    for (let row = 0; row < 4; row++) {
      ctx.save();
      ctx.fillStyle = (Math.floor(x/tileSize) + row) % 2 === 0 ? "#fff" : "#00ff9f";
      ctx.shadowBlur = 10;
      ctx.shadowColor = "#00ff9f";
      ctx.globalAlpha = 0.9;
      ctx.fillRect(x, y + row * tileSize, tileSize, tileSize);
      ctx.restore();
    }
  }

  ctx.save();
  ctx.font = 'bold 1.5rem Montserrat, Arial';
  ctx.fillStyle = '#fff';
  ctx.shadowBlur = 10;
  ctx.shadowColor = '#00ff9f';
  ctx.textAlign = 'center';
  ctx.fillText('META', width / 2, y - 30);
  ctx.restore();
}

function drawCountdown() {
  if(gameReallyStarted) return;

  let remaining = Math.max(1, Math.ceil(countdownTimer));

  ctx.save();
  ctx.font = 'bold 4rem Montserrat, Arial';
  ctx.fillStyle = '#ff007f';
  ctx.shadowBlur = 20;
  ctx.shadowColor = '#ff007f';
  ctx.textAlign = 'center';
  ctx.fillText(remaining, width / 2, height / 2);
  ctx.restore();

  ctx.save();
  ctx.font = 'bold 1.5rem Montserrat, Arial';
  ctx.fillStyle = '#fff';
  ctx.shadowBlur = 10;
  ctx.shadowColor = '#ff007f';
  ctx.textAlign = 'center';
  ctx.fillText('PREPARARSE', width / 2, height / 2 + 80);
  ctx.restore();
}

function drawPlayer() {
  ctx.save();
  let img = assets.player;
  let {x, y, width: w, height: h, rotation} = player;
  ctx.translate(x, y);
  if(rotation) ctx.rotate(rotation);
  ctx.drawImage(img, -w / 2, -h / 2, w, h);
  if (crashTimer > 0.5) ctx.drawImage(assets.crash, -w / 2, -h / 2, w, h);
  ctx.restore();
  if (shakeTimer > 0) {
    if(Math.random() > 0.5) player.x += 5;
    else player.x -= 5;
  }
}

function drawTurboTrail() {
  if(!turboActive) return;
  
  ctx.save();
  
  let trailX = player.x;
  let trailY = player.y + player.height / 2 + 40;
  
  let pulseScale = 0.8 + Math.sin(performance.now() / 100) * 0.2;
  
  // Triángulo amarillo exterior
  ctx.fillStyle = '#ffff00';
  ctx.globalAlpha = 0.8;
  ctx.shadowBlur = 15;
  ctx.shadowColor = '#ffff00';
  
  ctx.beginPath();
  ctx.moveTo(trailX, trailY - 25 * pulseScale);
  ctx.lineTo(trailX - 20 * pulseScale, trailY + 15 * pulseScale);
  ctx.lineTo(trailX + 20 * pulseScale, trailY + 15 * pulseScale);
  ctx.closePath();
  ctx.fill();
  
  // Triángulo naranja interior
  ctx.fillStyle = '#ff8800';
  ctx.globalAlpha = 0.9;
  ctx.shadowBlur = 10;
  ctx.shadowColor = '#ff8800';
  
  let innerScale = pulseScale * 0.6;
  ctx.beginPath();
  ctx.moveTo(trailX, trailY - 15 * innerScale);
  ctx.lineTo(trailX - 12 * innerScale, trailY + 10 * innerScale);
  ctx.lineTo(trailX + 12 * innerScale, trailY + 10 * innerScale);
  ctx.closePath();
  ctx.fill();
  
  ctx.restore();
}

function drawTurboStatus() {
  if(!turboActive) return;

  ctx.save();
  ctx.font = 'bold 2rem Montserrat, Arial';
  ctx.fillStyle = '#f6ff00';
  ctx.shadowBlur = 20;
  ctx.shadowColor = '#f6ff00';
  ctx.textAlign = 'left';

  const posX = 10;
  const posY = height / 2;
  
  ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
  ctx.fillRect(posX - 5, posY - 40, 200, 90);
  
  ctx.fillStyle = '#f6ff00';
  ctx.fillText('⚡ TURBO', posX + 5, posY - 10);
  ctx.font = 'bold 1.5rem Montserrat, Arial';
  ctx.fillText('⏱ ' + Math.ceil(turboTimer) + 's', posX + 5, posY + 20);
  
  let turboProgress = turboTimer / TURBO_DURATION;
  ctx.fillStyle = '#ff00ff';
  ctx.fillRect(posX + 5, posY + 35, 150 * turboProgress, 15);
  ctx.strokeStyle = '#07fff7';
  ctx.lineWidth = 2;
  ctx.strokeRect(posX + 5, posY + 35, 150, 15);
  
  ctx.restore();
}

function spawnEnemy() {
  if(enemies.length >= ACTIVE_CONFIG.maxEnemies) return;

  let lane = Math.floor(Math.random() * lanes);
  let y = ACTIVE_CONFIG.enemySpawnY;

  let tooClose = enemies.some(e =>
    e.lane === lane && Math.abs(e.y - y) < 200
  ) || obstacles.some(o =>
    Math.abs(o.y - y) < 200
  );

  if(!tooClose) {
    let hasHorizontalMovement = Math.random() < 0.6;
    let horizontalDirection = Math.random() < 0.5 ? -1 : 1;

    enemies.push({
      lane,
      x: lanePositions[lane],
      baseX: lanePositions[lane],
      y,
      speed: ACTIVE_CONFIG.enemyBaseSpeed + Math.random() * 1,
      hasHorizontalMovement: hasHorizontalMovement,
      horizontalDirection: horizontalDirection,
      horizontalOffset: 0,
      closePassed: false,
      lastY: y
    });
  }
}

function updateEnemies(delta) {
  enemies.forEach(e => {
    let speedMultiplier = enemyTurboTimer > 0 ? ENEMY_TURBO_MULTIPLIER : 1;
    e.y += e.speed * speedMultiplier;

    if(e.hasHorizontalMovement) {
      let maxOffset = laneWidth * 0.25;
      e.horizontalOffset += ENEMY_HORIZONTAL_SPEED * e.horizontalDirection;

      let newX = e.baseX + e.horizontalOffset;

      if(newX - 32 * SCALE_ENEMY <= ROAD_LEFT_LIMIT) {
        e.horizontalDirection = 1;
        e.horizontalOffset = Math.max(e.horizontalOffset, ROAD_LEFT_LIMIT - e.baseX + 32 * SCALE_ENEMY);
      } else if(newX + 32 * SCALE_ENEMY >= ROAD_RIGHT_LIMIT()) {
        e.horizontalDirection = -1;
        e.horizontalOffset = Math.min(e.horizontalOffset, ROAD_RIGHT_LIMIT() - e.baseX - 32 * SCALE_ENEMY);
      }

      e.x = e.baseX + e.horizontalOffset;
    } else {
      e.x = e.baseX;
    }
  });

  enemies = enemies.filter(e => e.y < height + 150);
}

function drawEnemies() {
  enemies.forEach(e => {
    ctx.save();
    ctx.translate(e.x, e.y);
    ctx.drawImage(assets.enemy,
      -32 * SCALE_ENEMY,
      -54 * SCALE_ENEMY,
      64 * SCALE_ENEMY,
      108 * SCALE_ENEMY
    );
    ctx.restore();
  });
}

function spawnObstacle() {
  if(obstacles.length >= ACTIVE_CONFIG.maxObstacles) return;

  let types = ['cone', 'barrier', 'puddle', 'turbo'];
  let obstacleType = types[Math.floor(Math.random() * types.length)];
  
  // Posición X aleatoria dentro de la carretera sin salir del borde
  let roadLeftBound = 18 + 30;
  let roadRightBound = width - 18 - 30;
  let randomX = roadLeftBound + Math.random() * (roadRightBound - roadLeftBound);
  
  let y = ACTIVE_CONFIG.obstacleSpawnY;

  // Verificar que no haya obstáculos muy cerca en el eje Y
  let tooClose = obstacles.some(o =>
    Math.abs(o.y - y) < 200
  ) || enemies.some(e =>
    Math.abs(e.y - y) < 200
  );

  if(!tooClose) {
    obstacles.push({
      type: obstacleType,
      x: randomX,
      baseX: randomX,
      y: y,
      touched: false
    });
  }
}

function updateObstacles(delta) {
  obstacles.forEach(o => {
    // Solo actualizar Y, X permanece fijo
    o.y += player.speed * delta * OBSTACLE_DESCENT_MULTIPLIER;
  });

  obstacles = obstacles.filter(o => o.y < height + 150);
}

function drawObstacles() {
  obstacles.forEach(o => {
    ctx.save();
    let img = assets[o.type];
    if(img) {
      let w = img.width * SCALE_OBSTACLE;
      let h = img.height * SCALE_OBSTACLE;
      ctx.drawImage(img, o.x - w/2, o.y - h/2, w, h);
    }
    ctx.restore();
  });
}

function checkFinishLine() {
  if(Math.abs(finishLineY - player.y) < ACTIVE_CONFIG.finishLineThreshold && finishLineY > 100) {
    endGame();
  }
}

function endGame() {
  running = false;
  showCelebration = true;
  saveHighScore();
}

function checkCollisions() {
  enemies.forEach(e => {
    if(e.lastY === undefined) e.lastY = e.y;

    let distX = Math.abs(e.x - player.x);
    let distY = Math.abs(e.y - player.y);
    let distance = Math.sqrt(distX * distX + distY * distY);

    // Solo restar puntos si el jugador no está girando (sin colisión previa)
    if(distX < ACTIVE_CONFIG.playerCollisionRadiusX && distY < ACTIVE_CONFIG.playerCollisionRadiusY && crashTimer <= 0) {
      triggerCrash();
      score = Math.max(0, score - ACTIVE_CONFIG.crashPointsPenalty);
      e.closePassed = false;
      if(sounds.crashSound) sounds.crashSound.play();
    } else {
      // Solo sumar puntos si el vehículo no está girando (no hay crash)
      if(e.lastY < player.y && e.y >= player.y && distance < CLOSE_DISTANCE && !e.closePassed && player.rotation === 0) {
        score += ACTIVE_CONFIG.closePassReward;
        e.closePassed = true;
        if(sounds.pointSound) sounds.pointSound.play();
      }
    }
    e.lastY = e.y;
  });

  obstacles.forEach(o => {
    // Colisión sin basarse en lanes
    if (Math.abs(o.x - player.x) < ACTIVE_CONFIG.obstacleCollisionRadiusX && 
        Math.abs(o.y - player.y) < ACTIVE_CONFIG.obstacleCollisionRadiusY && 
        !o.touched && crashTimer <= 0) {
      o.touched = true;

      if(o.type === 'cone' || o.type === 'barrier') {
        score = Math.max(0, score - ACTIVE_CONFIG.obstaclePointsPenalty);
        player.speed *= ACTIVE_CONFIG.crashSpeedMultiplier;
        setTimeout(() => {
          player.speed = player.baseSpeed;
        }, ACTIVE_CONFIG.crashDuration * 1000);
        if(sounds.crashSound) sounds.crashSound.play();

      } else if(o.type === 'puddle') {
        score = Math.max(0, score - ACTIVE_CONFIG.obstaclePointsPenalty);
        triggerPuddleCrash();
        if(sounds.crashSound) sounds.crashSound.play();

      } else if(o.type === 'turbo') {
        // Solo sumar puntos del turbo si no está girando
        if(player.rotation === 0) {
          score += ACTIVE_CONFIG.turboPointsReward;
        }
        activateTurbo();
        if(sounds.pointSound) sounds.pointSound.play();
      }
    }
  });
}


function activateTurbo() {
  turboActive = true;
  turboTimer = TURBO_DURATION;
  player.speed = player.baseSpeed * TURBO_SPEED_MULTIPLIER;
  enemyTurboTimer = ENEMY_TURBO_DURATION;
}

function triggerCrash() {
  player.speed *= ACTIVE_CONFIG.crashSpeedMultiplier;
  player.rotation = 0;
  crashTimer = ACTIVE_CONFIG.crashDuration;
  turboActive = false;
  turboTimer = 0;

  let startTime = performance.now();
  let rotationInterval = setInterval(() => {
    let elapsed = (performance.now() - startTime) / 1000;
    if(elapsed >= ACTIVE_CONFIG.crashDuration) {
      player.rotation = 0;
      clearInterval(rotationInterval);
    } else {
      player.rotation = (elapsed / ACTIVE_CONFIG.crashDuration) * Math.PI * 2;
    }
  }, 16);
}

function triggerPuddleCrash() {
  player.speed *= ACTIVE_CONFIG.puddleCrashMultiplier;
  shakeTimer = ACTIVE_CONFIG.shakeRecoveryTime;
  player.rotation = 0;
  crashTimer = ACTIVE_CONFIG.crashDuration;
  turboActive = false;
  turboTimer = 0;

  let startTime = performance.now();
  let rotationInterval = setInterval(() => {
    let elapsed = (performance.now() - startTime) / 1000;
    if(elapsed >= ACTIVE_CONFIG.crashDuration) {
      player.rotation = 0;
      clearInterval(rotationInterval);
      shakeTimer = 0;
    } else {
      player.rotation = (elapsed / ACTIVE_CONFIG.crashDuration) * Math.PI * 2;
    }
  }, 16);

  setTimeout(() => {
    player.speed = player.baseSpeed;
  }, ACTIVE_CONFIG.shakeRecoveryTime * 1000);
}

function updateBattery() {
  let percent = gameTime / GAME.duration;
  batteryLevel = Math.floor(percent * GAME.batteryStates);
  batteryLevel = Math.max(0, Math.min(4, batteryLevel));
}

function drawBattery() {
  ctx.save();
  let img = assets.battery[batteryLevel];
  if(img) {
    let x = width / 2 - 40, y = height * 0.08;
    ctx.drawImage(img, x, y, 80, 80);
    ctx.font = 'bold 2.2rem Montserrat, Arial';
    ctx.fillStyle = '#fff';
    ctx.shadowBlur = 6;
    ctx.shadowColor = '#444';
    ctx.textAlign = 'left';
    ctx.fillText(score, x + 84, y + 58);
  }
  ctx.restore();
}

function drawScoreHUD() {
  ctx.save();
  ctx.font = 'bold 1.3rem Montserrat, Arial';
  ctx.fillStyle = '#fff';
  ctx.shadowBlur = 5;
  ctx.shadowColor = '#e4067a';
  ctx.textAlign = 'right';
  ctx.fillText('Tiempo: ' + Math.max(0, Math.ceil(gameTime)) + 's', width - 36, 44);
  ctx.fillText('Puntaje: ' + score, width - 36, 70);
  ctx.restore();
}

function drawCelebration() {
  ctx.clearRect(0, 0, width, height);
  if(assets.celebration) {
    ctx.save();
    let imgWidth = assets.celebration.width;
    let imgHeight = assets.celebration.height;
    let aspectRatio = imgWidth / imgHeight;

    let drawWidth, drawHeight, drawX, drawY;

    if(width / height > aspectRatio) {
      drawWidth = width;
      drawHeight = width / aspectRatio;
      drawX = 0;
      drawY = (height - drawHeight) / 2;
    } else {
      drawWidth = height * aspectRatio;
      drawHeight = height;
      drawX = (width - drawWidth) / 2;
      drawY = 0;
    }

    ctx.drawImage(assets.celebration, drawX, drawY, drawWidth, drawHeight);
    ctx.restore();
  }

  ctx.save();
  ctx.font = 'bold 2.3rem Montserrat, Arial';
  ctx.fillStyle = '#fff';
  ctx.shadowBlur = 10;
  ctx.shadowColor = '#0ff';
  ctx.textAlign = 'center';
  ctx.fillText('¡Puntaje final: ' + score + '!', width / 2, height - 130);
  ctx.restore();
}

function saveHighScore() {
  let hs = localStorage.getItem('neon_race_highscore');
  if (!hs || score > hs) {
    localStorage.setItem('neon_race_highscore', score);
    console.log(score);
     pasarValor(score,documento);
  }else{
      pasarValor(hs,documento);
  }
 
}

function pasarValor(score, doc) {
   setTimeout(() => {
    // Cambiar a pagina.php enviando dos valores como parámetros GET
    const url = `Logica/introduci.php?score=${encodeURIComponent(score)}&doc=${encodeURIComponent(doc)}`;
    window.location.href = url;
  }, 5000); // 5000 ms = 5 segundos
}
