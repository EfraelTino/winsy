<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Ranking Neon con Imagen y Top 10</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:700&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        /* Aquí va todo tu CSS del estilo que compartiste */
        body {

            background: linear-gradient(135deg, #fa008a 0%, #d10cf7 52%, #ba0ffe 100%);
            font-family: 'Montserrat', Arial, sans-serif;
        }

        .top-image {
            width: 80vw;
            max-width: 480px;
            height: auto;
            margin: 32px 0 18px 0;
            display: block;
            border: none;
            background: none;
        }

        .ranking-box {
            background: rgba(17, 0, 32, 0.6);
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            position: relative;
            z-index: 1;
            box-shadow: 0 0 50px 20px #4e21b3bb, 0 0 40px 16px #0ff2fe55 inset;
        }

        .ranking-box::before {
            content: '';
            position: absolute;
            z-index: -1;
            top: -8px;
            left: -8px;
            right: -8px;
            bottom: -8px;
            border-radius: 40px;
            background: conic-gradient(#be20e2 0deg,
                    #d344ff 65deg,
                    #ff00f2 130deg,
                    #a428fd 220deg,
                    #d220e2 320deg,
                    #ff44e6 360deg);
            filter: blur(4.5px);
            opacity: 0.75;
        }

        .ranking-box::after {
            content: '';
            position: absolute;
            z-index: -2;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: 32px;
            background: rgba(17, 0, 32, 0.6);
        }

        .top-title {
            color: #fff;
            font-size: 2.1rem;
            font-weight: 700;
            text-align: center;
            letter-spacing: 2px;
            margin-bottom: 16px;
            margin-top: 0;
            text-shadow:
                0 0 8px #fff,
                0 0 18px #c916ff,
                0 0 34px #fa008a99;
        }

        .ranking-list {
            list-style: none;
            padding: 0;
            margin: 0;
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .ranking-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: #fff;
            margin-bottom: 13px;
            font-weight: 700;
            font-size: 1.7rem;
            letter-spacing: 1px;
            text-shadow:
                0 0 12px #fff,
                0 0 35px #f2bdf9;
        }

        .ranking-row:last-child {
            margin-bottom: 0;
        }

        .player-name {
            text-align: left;
            flex: 1 1 60%;
            word-break: break-all;
        }

        .player-score {
            min-width: 66px;
            text-align: right;
            font-variant-numeric: tabular-nums;
            padding-left: 16px;
            flex: 0 0 auto;
        }

        @media (max-width: 430px) {
            .top-image {
                max-width: 98vw;
                width: 98vw;
            }

            .ranking-box {
                max-width: 98vw;
                width: 98vw;
                padding-right: 4vw;
                padding-left: 4vw;
            }

            .ranking-row {
                font-size: 1.14rem;
            }

            .player-score {
                min-width: 36px;
            }

            .top-title {
                font-size: 1.4rem;
            }
        }
    </style>
</head>

<body class="flex flex-col justify-center h-screen items-center p-20 w-full space-y-10">
    <img src="assets/logo.png" alt="Imagen Superior" class="top-image">

    <div class="ranking-box w-full px-12 py-16 rounded-3xl">
        <div class="top-title">TOP 10</div>
        <ul class="ranking-list">
            <li>
                    <li class="ranking-row border-b border-white/20 py-3">
                    <span class="player-score text-center text-3xl">#</span>
                    <span class="player-name text-3xl"> Nombres </span>
                    <span class="player-score text-3xl">Puntaje</span>
                    </li>'
            </li>
            <?php
            require './Logica/conexion.php';

         $sql = mysqli_query($dblink, "SELECT nombre, puntos FROM jugadores ORDER BY puntos DESC LIMIT 10");

if (mysqli_num_rows($sql) > 0) {
    $pos = 0;
    while ($fila = mysqli_fetch_assoc($sql)) {
        $pos++;
        echo '<li class="ranking-row border-b border-white/20 py-3">';
        echo '<span class="player-score text-center text-3xl">' . $pos . '</span>';
        echo '<span class="player-name text-3xl">' . htmlspecialchars($fila['nombre']) . '</span>';
        echo '<span class="player-score text-center text-3xl">' . str_pad($fila['puntos'], 3, "0", STR_PAD_LEFT) . '</span>';
        echo '</li>';
    }
} else {
    echo '<li class="ranking-row"><span class="player-name">No hay datos</span><span class="player-score">000</span></li>';
}
            ?>
        </ul>
    </div>
</body>

</html>