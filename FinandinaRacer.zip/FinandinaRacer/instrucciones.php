<?php
$documento = $_GET['documento'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instrucciones del juego</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<style>
    *{
  overflow: hidden;
    }
    .bg-principal {
        background: #d34d68;
    }

    .bg-buttons {
        background: linear-gradient(90deg, rgba(156, 97, 214, 1) 0%, rgba(229, 76, 53, 1) 100%);
    }

    .text-shadow-title {
        text-shadow: 0px 1px 8px #ff7bf8;
    }
</style>

<body class="bg-principal min-h-screen bg-cover bg-no-repeat bg-center flex flex-col justify-evenly items-center p-0 m-0">
    <img src="./assets/2.png" alt="">
</body>

<script>
window.addEventListener('load', () => {
    setTimeout(() => {
        window.location.href = "./juego.php?documento=<?= urlencode($documento) ?>";
    }, 5000);
});
</script>

</html>
