<?php
include "./conexion.php";
date_default_timezone_set('America/Bogota');
$fecha = date('Y-m-d H:i:s');

$nombre = $_POST['nombre'] ?? '';
$documento = $_POST['documento'] ?? '';
$email = $_POST['email'] ?? '';
$telefono = $_POST['telefono'] ?? '';

if (!$dblink) {
    die("Error de conexión: " . mysqli_connect_error());
}

$sql = mysqli_query($dblink, "SELECT * FROM jugadores WHERE documento='$documento'");
$row = mysqli_num_rows($sql);

if ($row > 0) {
    $mensaje = "Este documento ya se encuentra registrado";
    $s = "YA SE REGISTRÓ";
    $link = "../index.html";
    $link_ms = "REGRESAR";
    header("Location: ../mensaje.php?mensaje=" . urlencode($mensaje) . "&s=" . urlencode($s) . "&link=" . urlencode($link) . "&link_ms=" . urlencode($link_ms));
    exit;
} else {
    $intentos = 0;
    $puntos = 0;
    $fechaj = '';

    $stmt = $dblink->prepare("INSERT INTO jugadores (nombre, email, telefono, documento, intentos, puntos, fecha, fechaj) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssiissss", $nombre, $email, $telefono, $documento, $intentos, $puntos, $fecha, $fechaj);

    if ($stmt->execute()) {
        header("Location: ../instrucciones.php?documento=" . urlencode($documento));
        exit;
    } else {
        echo "NO REGISTRADO: " . $stmt->error;
    }
}
?>
