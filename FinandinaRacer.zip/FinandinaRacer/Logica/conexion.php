<?php 
   /**
    *  $host = "localhost";
   *  $user = "root";
    * $pass = "Root123!";
     * $database = "FinandinaRacer";
 */
 $host = "localhost";
  $user = "u694359124_finandina";
  $pass = "b$6F^|929!h";
 $database = "u694359124_finandina";
   
   $dblink = mysqli_connect($host, $user, $pass, $database);
   if($dblink){
    //echo "conectado";
   }else{echo "NO ESTA CONECTADO";
}

?>
