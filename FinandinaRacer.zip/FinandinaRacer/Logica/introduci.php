<?php
require 'conexion.php';
$score = $_GET['score'];
$doc = $_GET['doc'];

date_default_timezone_set('America/Bogota');
$fecha = date('m-d-Y h:i:s', time());

$sql = mysqli_query($dblink, "SELECT * FROM jugadores WHERE documento='$doc'");
$row = mysqli_fetch_assoc($sql);



$intentos = $row['intentos'];
$intentos = $intentos+1 ;

echo $intentos." ".$doc." ".$score;

$row = mysqli_num_rows($sql);
if ($row > 0) {
	$sql_update = mysqli_query($dblink, "UPDATE jugadores SET puntos='$score', fechaj='$fecha', intentos='$intentos' WHERE documento='$doc'") or die(mysqli_error($dblink));
    header("Location: ../final.php?puntos=$score");
    exit;
} else {
	echo "Error";
}




/*
$stmt = $dblink->prepare("UPDATE `jugadores` SET `puntos` = ? , `fechaj` = ?, `intentos` = ? WHERE documento = ?  ");
if (!$stmt) {
    echo "error";
}else{
    $stmt->bind_param('ssss', $score, $fecha, $intentos, $documento);
    $stmt->execute();
    $stmt->close();
    echo " aca estamos.";    
}
*/

?>